package com.example.test;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;

import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.os.Bundle;

public class MainActivity2 extends AppCompatActivity {
   // private DBHelper dbHelper;
    Button startbutton;
    Button aboutbutton;
    EditText nametext;
  //  SQLiteDatabase db;
 //   String selectQuery;
    int i;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

         startbutton=(Button)findViewById(R.id.button);
         aboutbutton=(Button)findViewById(R.id.button2);
         nametext=(EditText)findViewById(R.id.editName);

        startbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name=nametext.getText().toString();
              //  db = dbHelper.getWritableDatabase();
                if(TextUtils.isEmpty(name)) {
                    nametext.setError("Enter your name");

                }
                else {
                    Intent intent = new Intent(getApplicationContext(), QuestionActivity.class);
                    intent.putExtra("myname", name);
                    startActivity(intent);
                }

            }
        });



        aboutbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),Developer.class);
                startActivity(intent);
            }
        });


    }
}