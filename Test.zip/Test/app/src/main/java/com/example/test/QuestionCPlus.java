package com.example.test;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class QuestionCPlus extends AppCompatActivity {

        TextView tv;
        Button submitbutton,quitbutton;
        RadioGroup radio_g;
        RadioButton rb1,rb2,rb3,rb4;

    String questions []= {
            "1) Format flags may be combined using",
            "2) Which of the following is the correct syntax to print the message in C++ language?",
            "3) Which of the following is the correct identifier?",
            "4) Which of the following is the address operator?",
            "5) Which of the following features must be supported by any programming language to become a pure object-oriented programming language?",
            "6) The programming language that has the ability to create new data types is called___.",
            "7) Which of the following is the original creator of the C++ language?",
            "8) Which of the following is the correct syntax to read the single character to console in the C++ language?",
            "9) Which of the following comment syntax is correct to create a single-line comment in the C++ program?",
            "10) Which one is not a correct variable type in C++?"

    };
    String answers[] = {"the bitwise OR operator (|)","VAR_123","&","All of the above","Extensible","Bjarne Stroustrup","get(ch)","//Comment","Middle-level language","real"};
    String opt[] = {
            "the bitwise OR operator (|)","the logical OR operator (||)","the bitwise AND operator (&)","the logical AND operator (&&)",
            "$var_name","VAR_123","varname@","None of the above",
            "@","#","&","%",
            "Encapsulation","Inheritance","Polymorphism","All of the above",
            "Overloaded","Encapsulation","Reprehensible","Extensible",
            "Dennis Ritchie","Ken Thompson","Bjarne Stroustrup","Brian Kernighan",
            "get(ch)","Read ch()","Getline vh()","Scanf(ch)",
            "//Comment","/Comment/","Comment//","None of the  above",
            "High-level language","Low-level language","Middle-level language","None of the above",
            "float","real","int","double"

    };

        int flag=0;
        public static int marks=0,correct=0,wrong=0;
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_question_cplus);

            final TextView score = (TextView)findViewById(R.id.textView4);
            TextView textView=(TextView)findViewById(R.id.DispName);
            Intent intent = getIntent();
            String name= intent.getStringExtra("myname");

                textView.setText("Hello " + name+"\nSubject C++");

            submitbutton=(Button)findViewById(R.id.button3);
            quitbutton=(Button)findViewById(R.id.buttonquit);
            tv=(TextView) findViewById(R.id.tvque);

            radio_g=(RadioGroup)findViewById(R.id.answersgrp);
            rb1=(RadioButton)findViewById(R.id.radioButton);
            rb2=(RadioButton)findViewById(R.id.radioButton2);
            rb3=(RadioButton)findViewById(R.id.radioButton3);
            rb4=(RadioButton)findViewById(R.id.radioButton4);
            tv.setText(questions[flag]);
            rb1.setText(opt[0]);
            rb2.setText(opt[1]);
            rb3.setText(opt[2]);
            rb4.setText(opt[3]);
            submitbutton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //int color = mBackgroundColor.getColor();
                    //mLayout.setBackgroundColor(color);

                    if(radio_g.getCheckedRadioButtonId()==-1)
                    {
                        Toast.makeText(getApplicationContext(), "Please select one choice", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    RadioButton ans = (RadioButton) findViewById(radio_g.getCheckedRadioButtonId());
                    String ansText = ans.getText().toString();
//                Toast.makeText(getApplicationContext(), ansText, Toast.LENGTH_SHORT).show();
                    if(ansText.equals(answers[flag])) {
                        correct++;
                        Toast.makeText(getApplicationContext(), "Correct", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        wrong++;
                        Toast.makeText(getApplicationContext(), "Wrong", Toast.LENGTH_SHORT).show();
                    }

                    flag++;

                    if (score != null)
                        score.setText(""+correct);

                    if(flag<questions.length)
                    {
                        tv.setText(questions[flag]);
                        rb1.setText(opt[flag*4]);
                        rb2.setText(opt[flag*4 +1]);
                        rb3.setText(opt[flag*4 +2]);
                        rb4.setText(opt[flag*4 +3]);
                    }
                    else
                    {
                        marks=correct;
                        Intent in = new Intent(getApplicationContext(),ResultCPlus.class);
                        startActivity(in);
                    }
                    radio_g.clearCheck();
                }
            });

            quitbutton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent=new Intent(getApplicationContext(),ResultCPlus.class);
                    startActivity(intent);
                }
            });

        }
    }