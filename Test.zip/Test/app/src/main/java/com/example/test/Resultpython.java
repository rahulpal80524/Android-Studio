package com.example.test;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Resultpython extends AppCompatActivity {
    TextView tv,tv2,tv3;
    Button btnRestart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultpython);


        tv = (TextView)findViewById(R.id.tvres);
        tv2 = (TextView)findViewById(R.id.tvres2);
        tv3 = (TextView)findViewById(R.id.tvres3);
        btnRestart = (Button) findViewById(R.id.btnRestart);

        StringBuffer pb = new StringBuffer();
        pb.append("Correct answers: " + Quesionpython.correct + "\n");
        StringBuffer pb2 = new StringBuffer();
        pb2.append("Wrong Answers: " + Quesionpython.wrong + "\n");
        StringBuffer pb3 = new StringBuffer();
        pb3.append("Final Score: " + Quesionpython.correct + "\n");
        tv.setText(pb);
        tv2.setText(pb2);
        tv3.setText(pb3);

        Quesionpython.correct=0;
        Quesionpython.wrong=0;



        btnRestart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(in);
            }
        });
    }
}