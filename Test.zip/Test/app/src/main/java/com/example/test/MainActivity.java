package com.example.test;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button b1,b2,b3,b4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=findViewById(R.id.button10);
        b2=findViewById(R.id.button7);
        b3=findViewById(R.id.button5);
        b4=findViewById(R.id.button6);
       // b1.setOnClickListener(this);
      //  b2.setOnClickListener(this);
     //   b3.setOnClickListener(this);
     //   b4.setOnClickListener(this);



    }
      public void java(View view){
       Intent intent= new Intent(this,MainActivity2.class);
       startActivity(intent);
    }

    public void python(View view){
        Intent intent= new Intent(this,MainActivity3.class);
        startActivity(intent);
    }

    public void c(View view){
        Intent intent= new Intent(this,MainActivity4.class);
        startActivity(intent);
    }

    public void c_plus(View view){
        Intent intent= new Intent(this,MainActivity5.class);
        startActivity(intent);
    }
}